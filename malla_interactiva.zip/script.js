const mallaDiv = document.getElementById("malla");

const ramos = [
  { nombre: "Química General", semestre: 1, prerrequisitos: [] },
  { nombre: "Química Orgánica", semestre: 2, prerrequisitos: ["Química General"] }
];

let aprobados = [];

function crearRamo(ramo) {
  const div = document.createElement("div");
  div.className = "ramo";
  div.textContent = ramo.nombre;
  return div;
}

function actualizarTodo() {
  mallaDiv.innerHTML = "";
  for (let i = 1; i <= 10; i++) {
    const col = document.createElement("div");
    col.className = "columna";

    const h2 = document.createElement("h2");
    h2.textContent = `Semestre ${i}`;
    col.appendChild(h2);

    ramos.filter(r => r.semestre === i).forEach(r => {
      const ramoDiv = crearRamo(r);
      col.appendChild(ramoDiv);
    });

    mallaDiv.appendChild(col);
  }
}

actualizarTodo();
